function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="inline-block";
	
 var name=document.getElementById("name_row"+no);
 var dept=document.getElementById("dept_row"+no);
 var mob=document.getElementById("mob_row"+no);
	
 var name_data=name.innerHTML;
 var dept_data=dept.innerHTML;
 var mob_data=mob.innerHTML;
	
 name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 dept.innerHTML="<input type='text' id='dept_text"+no+"' value='"+dept_data+"'>";
 mob.innerHTML="<input type='text' id='mob_text"+no+"' value='"+mob_data+"'>";
}

function save_row(no)
{
 var name_val=document.getElementById("name_text"+no).value;
 var dept_val=document.getElementById("dept_text"+no).value;
 var mob_val=document.getElementById("mob_text"+no).value;

 document.getElementById("name_row"+no).innerHTML=name_val;
 document.getElementById("dept_row"+no).innerHTML=dept_val;
 document.getElementById("mob_row"+no).innerHTML=mob_val;

 document.getElementById("edit_button"+no).style.display="inline-block";
 document.getElementById("save_button"+no).style.display="none";

 if(name_val.search(/[a-z]/)<0){
    alert("Please enter the Alphabates ");
 }
 if(dept_val.search(/[a-z]/)<0){
    alert("Please enter the Alphabates ");
 }
 if(mob_val.search(/[0-9]/)<0){
    alert("Mobile number should be Number type");

}
 if(name_val==""&&dept_val==""&&mob_val=="")
 {
    alert("please fill the all input fields !");
 }
 else if(name_val==""&&dept_val=="")
 {
    alert("please fill the Name and Department !");
 }
  else if(dept_val==""&&mob_val=="")
 {
    alert("please fill the Department and Mobile number!");
 }
  else if(name_val=="")
 {
    alert("please Enter the Name!");
 }
  else if(dept_val=="")
 {
    alert("please Enter the Department!");
 }
  else if(mob_val=="")
 {
    alert("please enter the Mobile number!");
 }
 
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_name=document.getElementById("new_name").value;
 var new_dept=document.getElementById("new_dept").value;
 var new_mob=document.getElementById("new_mob").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='name_row"+table_len+"'>"+new_name+
 "</td><td id='dept_row"+table_len+"'>"+new_dept+"</td><td id='mob_row"+table_len+"'>"+new_mob+
 "</td><td><i class='fa fa-pencil-square-o' aria-hidden='true' id='edit_button"+table_len+
 "' value='Edit' class='edit' style='color:goldenrod;' onclick='edit_row("+table_len+
  ")'></i><i class='fa fa-save' id='save_button"+table_len+"' class='save' style='color:green;display:none;' onclick='save_row("
  +table_len+ ")'></i> <i class='fa fa-trash-o' class='delete' style='color:red;' onclick='delete_row("+table_len+")'></i> </td></tr>";

document.getElementById("new_name").value="";
 document.getElementById("new_dept").value="";
document.getElementById("new_mob").value="";
 

}
